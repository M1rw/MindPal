import test from "node:test";
import assert from "node:assert/strict";

import {
  normalizeGeminiServerMessage,
  createGeminiLiveAdapter,
} from "../frontend/js/voice/provider/gemini_live_adapter.js";
import { createCaptureAdapter } from "../frontend/js/voice/capture/capture_adapter.js";
import { createPlaybackManager } from "../frontend/js/voice/playback/playback_manager.js";
import { createVoiceSessionOrchestrator } from "../frontend/js/voice/orchestrator/voice_session_orchestrator.js";
import { VOICE_EVENTS } from "../frontend/js/voice/architecture/events.js";
import { VOICE_PHASES } from "../frontend/js/voice/architecture/state.js";

test("Gemini adapter normalizes setup, transcripts, audio, interruption, and completion", () => {
  const events = normalizeGeminiServerMessage({
    setupComplete: {},
    serverContent: {
      inputTranscription: { text: "I had a difficult day" },
      outputTranscription: { text: "I hear you" },
      modelTurn: { parts: [{ inlineData: { data: "AQI=", mimeType: "audio/pcm;rate=24000" } }] },
      interrupted: true,
      turnComplete: true,
    },
  }, { sessionGeneration: 3, turnId: "turn-1", providerResponseId: "response-1", playbackGeneration: 2 });

  assert.deepEqual(events.map((event) => event.type), [
    VOICE_EVENTS.PROVIDER_READY,
    VOICE_EVENTS.PROVIDER_INPUT_TRANSCRIPT,
    VOICE_EVENTS.PROVIDER_OUTPUT_TRANSCRIPT,
    VOICE_EVENTS.PROVIDER_AUDIO,
    VOICE_EVENTS.PROVIDER_INTERRUPTED,
    VOICE_EVENTS.PROVIDER_TURN_COMPLETE,
  ]);
  assert.equal(events[3].base64Data, "AQI=");
  assert.equal(events[4].identity.turnId, "turn-1");
});

test("Gemini adapter sends setup and rejects stale sockets", () => {
  class FakeWebSocket {
    static OPEN = 1;
    constructor(url) {
      this.url = url;
      this.readyState = FakeWebSocket.OPEN;
      this.sent = [];
      FakeWebSocket.instances.push(this);
    }
    send(value) { this.sent.push(JSON.parse(value)); }
    close() { this.readyState = 3; }
  }
  FakeWebSocket.instances = [];
  const events = [];
  const adapter = createGeminiLiveAdapter({
    WebSocketImpl: FakeWebSocket,
    onEvent: (event) => events.push(event),
  });
  const socket = adapter.connect({
    url: "wss://example.test/live",
    setup: { model: "models/test", generationConfig: { responseModalities: ["AUDIO"] } },
    identity: { sessionGeneration: 1 },
  });
  socket.onopen();
  assert.deepEqual(socket.sent[0], { setup: { model: "models/test", generationConfig: { responseModalities: ["AUDIO"] } } });
  socket.onmessage({ data: JSON.stringify({ setupComplete: {} }) });
  assert.equal(events[0].type, VOICE_EVENTS.PROVIDER_READY);

  const firstSocket = socket;
  adapter.connect({ url: "wss://example.test/second", identity: { sessionGeneration: 2 } });
  firstSocket.onmessage({ data: JSON.stringify({ setupComplete: {} }) });
  assert.equal(events.length, 1);
});

test("capture adapter encodes PCM and never emits while muted or stopped", () => {
  const audio = [];
  const quality = [];
  const capture = createCaptureAdapter({
    onAudio: (frame) => audio.push(frame),
    onQuality: (signal) => quality.push(signal),
    now: (() => { let value = 100; return () => value += 10; })(),
  });
  const frame = new Float32Array([0, 0.5, -0.5, 1]);
  assert.equal(capture.processFrame(frame), false);
  capture.start();
  assert.equal(capture.processFrame(frame), true);
  assert.equal(audio.length, 1);
  assert.equal(audio[0].mimeType, "audio/pcm;rate=16000");
  assert.match(audio[0].base64Data, /^[A-Za-z0-9+/]+=*$/);
  assert.equal(quality.length, 1);
  capture.setMuted(true);
  assert.equal(capture.processFrame(frame), false);
  capture.stop();
  assert.equal(capture.processFrame(frame), false);
});

test("playback manager rejects stale generations and flushes active output", () => {
  const events = [];
  const playback = createPlaybackManager({ onEvent: (event) => events.push(event) });
  assert.equal(playback.schedule("AQI=", { generation: 1 }), true);
  assert.equal(playback.schedule("AQI=", { generation: 0 }), false);
  const next = playback.handleInterruption({ playbackGeneration: 1 });
  assert.equal(next, 2);
  assert.equal(playback.getActiveGeneration(), 2);
  assert.ok(events.some((event) => event.type === "playback.flushed"));
});

test("orchestrator owns session state and translates provider interruption into playback invalidation", () => {
  const providerEvents = [];
  const provider = {
    connect: ({ identity }) => { providerEvents.push(["connect", identity]); },
    updateContext: (context) => { providerEvents.push(["context", context]); },
    sendText: (text) => { providerEvents.push(["text", text]); return true; },
    close: () => { providerEvents.push(["close"]); },
  };
  const capture = createCaptureAdapter();
  const playback = createPlaybackManager();
  const orchestrator = createVoiceSessionOrchestrator({ provider, capture, playback });

  assert.equal(orchestrator.start({ url: "wss://example.test", setup: {} }), true);
  assert.equal(orchestrator.getState().phase, VOICE_PHASES.CONNECTING);
  orchestrator.handleProviderEvent({ type: VOICE_EVENTS.PROVIDER_READY, identity: { sessionGeneration: 1 } });
  assert.equal(orchestrator.getState().phase, VOICE_PHASES.LISTENING);
  orchestrator.handleProviderEvent({ type: VOICE_EVENTS.PROVIDER_INPUT_TRANSCRIPT, text: "hello", identity: { sessionGeneration: 1 } });
  assert.equal(orchestrator.getState().phase, VOICE_PHASES.USER_SPEAKING);
  orchestrator.handleProviderEvent({ type: VOICE_EVENTS.PROVIDER_AUDIO, base64Data: "AQI=", identity: { sessionGeneration: 1 } });
  assert.equal(orchestrator.getState().phase, VOICE_PHASES.MODEL_SPEAKING);
  orchestrator.handleProviderEvent({ type: VOICE_EVENTS.PROVIDER_INTERRUPTED, identity: { sessionGeneration: 1 } });
  assert.equal(orchestrator.getState().phase, VOICE_PHASES.USER_SPEAKING);
  assert.equal(orchestrator.sendText("continue"), true);
  assert.equal(providerEvents.at(-1)[0], "text");
  assert.equal(orchestrator.stop(), true);
  assert.equal(orchestrator.getState().phase, VOICE_PHASES.IDLE);
});
