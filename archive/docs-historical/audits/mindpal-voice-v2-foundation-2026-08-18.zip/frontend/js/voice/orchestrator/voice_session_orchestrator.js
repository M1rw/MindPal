import {
  createVoiceIdentityFactory,
  createArtifactIdentity,
} from "../architecture/ids.js";
import {
  VOICE_EVENTS,
  createVoiceEvent,
} from "../architecture/events.js";
import {
  VOICE_ACTIONS,
  createInitialVoiceState,
  voiceStateReducer,
} from "../architecture/state.js";

export function createVoiceSessionOrchestrator({
  provider,
  capture,
  playback,
  now = () => Date.now(),
  identityFactory = createVoiceIdentityFactory({ now }),
  backchannelManager = null,
  responseStagingManager = null,
  toolGateway = null,
  evidenceGate = null,
  recoverySupervisor = null,
  persistence = null,
  onEvent = () => {},
} = {}) {
  if (!provider || typeof provider.connect !== "function") throw new TypeError("provider adapter is required");
  if (!capture || typeof capture.start !== "function") throw new TypeError("capture adapter is required");
  if (!playback || typeof playback.schedule !== "function") throw new TypeError("playback manager is required");

  let state = createInitialVoiceState({ now });
  let listeners = new Set();
  let started = false;

  function emit(event) {
    onEvent(event);
    for (const listener of listeners) listener(event, state);
  }

  function dispatch(action) {
    const previous = state;
    state = voiceStateReducer(state, action, { now });
    if (state !== previous) emit(createVoiceEvent(VOICE_EVENTS.CAPTURE_STATE, { action, state }));
    return state;
  }

  function currentIdentity({ playbackGeneration = state.playbackGeneration } = {}) {
    return createArtifactIdentity({
      sessionGeneration: state.sessionGeneration,
      turnId: state.activeTurnId,
      providerResponseId: state.activeProviderResponseId,
      playbackGeneration,
    });
  }

  function ensureTurn() {
    if (state.activeTurnId) return state.activeTurnId;
    const turnId = identityFactory.nextTurnId();
    dispatch({
      type: VOICE_ACTIONS.CAPTURE_SPEECH_STARTED,
      sessionGeneration: state.sessionGeneration,
      turnId,
    });
    return turnId;
  }

  function handleProviderEvent(event) {
    if (!event || !event.type) return;
    switch (event.type) {
      case VOICE_EVENTS.PROVIDER_READY:
        dispatch({ type: VOICE_ACTIONS.SESSION_READY, sessionGeneration: state.sessionGeneration });
        emit(event);
        return;
      case VOICE_EVENTS.PROVIDER_INPUT_TRANSCRIPT: {
        const turnId = ensureTurn();
        dispatch({
          type: VOICE_ACTIONS.INPUT_TRANSCRIPT_UPDATED,
          sessionGeneration: state.sessionGeneration,
          turnId,
          text: event.text,
        });
        if (backchannelManager && event.finished !== true) {
          backchannelManager.consider({
            sessionGeneration: state.sessionGeneration,
            turnId,
            speechDurationMs: event.speechDurationMs || 0,
            pauseDurationMs: event.pauseDurationMs || 0,
            transcriptConfidence: event.transcriptConfidence ?? 1,
            topic: event.topic || "story",
            emotion: event.emotion || "neutral",
            userHasYielded: false,
            isModelSpeaking: state.isModelSpeaking,
          });
        }
        emit(Object.freeze({ ...event, turnId }));
        return;
      }
      case VOICE_EVENTS.PROVIDER_OUTPUT_TRANSCRIPT:
        emit(event);
        return;
      case VOICE_EVENTS.PROVIDER_AUDIO: {
        const responseId = state.activeProviderResponseId || identityFactory.nextProviderResponseId();
        if (!state.activeProviderResponseId) {
          dispatch({
            type: VOICE_ACTIONS.MODEL_RESPONSE_STARTED,
            sessionGeneration: state.sessionGeneration,
            providerResponseId: responseId,
            turnId: state.activeTurnId,
          });
        }
        const playbackGeneration = state.playbackGeneration || identityFactory.nextPlaybackGeneration();
        const identity = currentIdentity({ playbackGeneration });
        if (event.identity?.sessionGeneration != null && event.identity.sessionGeneration !== state.sessionGeneration) return;
        playback.schedule(event.base64Data, {
          generation: playbackGeneration,
          audioClass: "main",
          identity,
        });
        dispatch({
          type: VOICE_ACTIONS.AUDIO_RECEIVED,
          sessionGeneration: state.sessionGeneration,
          playbackGeneration,
          audioClass: "main",
        });
        emit(Object.freeze({ ...event, identity }));
        return;
      }
      case VOICE_EVENTS.PROVIDER_INTERRUPTED: {
        backchannelManager?.cancel("provider-interrupted");
        responseStagingManager?.cancelForTurn(state.activeTurnId, "provider-interrupted");
        const playbackGeneration = playback.handleInterruption(event.identity || currentIdentity());
        dispatch({
          type: VOICE_ACTIONS.MODEL_INTERRUPTED,
          sessionGeneration: state.sessionGeneration,
          playbackGeneration,
        });
        emit(event);
        return;
      }
      case VOICE_EVENTS.PROVIDER_TURN_COMPLETE:
        backchannelManager?.cancel("turn-complete");
        dispatch({ type: VOICE_ACTIONS.TURN_COMPLETE, sessionGeneration: state.sessionGeneration });
        emit(event);
        return;
      case VOICE_EVENTS.PROVIDER_TOOL_CALL: {
        if (!toolGateway) {
          emit(Object.freeze({ ...event, error: "tool-gateway-not-configured" }));
          return;
        }
        const call = event.call || {};
        const operationId = identityFactory.nextOperationId();
        const identity = createArtifactIdentity({
          sessionGeneration: state.sessionGeneration,
          turnId: state.activeTurnId,
          providerResponseId: state.activeProviderResponseId,
          operationId,
        });
        dispatch({ type: VOICE_ACTIONS.TOOL_STARTED, sessionGeneration: state.sessionGeneration });
        void toolGateway.execute(call.name, call.args || call.arguments || {}, { identity })
          .then((result) => {
            if (identity.sessionGeneration !== state.sessionGeneration || identity.turnId !== state.activeTurnId) return;
            dispatch({ type: VOICE_ACTIONS.TOOL_RESOLVED, sessionGeneration: state.sessionGeneration });
            provider.sendToolResponse?.([{
              id: call.id,
              name: call.name,
              response: { result },
            }]);
            emit(createVoiceEvent(VOICE_EVENTS.TOOL_RESOLVED, { identity, result }));
          });
        return;
      }
      case VOICE_EVENTS.PROVIDER_GO_AWAY:
        dispatch({ type: VOICE_ACTIONS.RECOVERY_STARTED, sessionGeneration: state.sessionGeneration });
        if (recoverySupervisor) {
          void recoverySupervisor.recover({
            reason: "provider-go-away",
            resumeHandle: event.resumeHandle || null,
            continuity: { turnId: state.activeTurnId },
          }).then((result) => {
            if (result.ok) dispatch({ type: VOICE_ACTIONS.RECOVERY_READY, sessionGeneration: state.sessionGeneration });
            else dispatch({ type: VOICE_ACTIONS.RECOVERY_FAILED, sessionGeneration: state.sessionGeneration, error: result.error });
          });
        }
        emit(event);
        return;
      case VOICE_EVENTS.PROVIDER_ERROR:
        dispatch({ type: VOICE_ACTIONS.FAILED, sessionGeneration: state.sessionGeneration, error: event.error });
        emit(event);
        return;
      case VOICE_EVENTS.PROVIDER_CLOSED:
        if (started) dispatch({ type: VOICE_ACTIONS.RECOVERY_STARTED, sessionGeneration: state.sessionGeneration });
        emit(event);
        return;
      default:
        emit(event);
    }
  }

  function start({ url, setup, identity = {} } = {}) {
    if (started) return false;
    const sessionGeneration = identity.sessionGeneration || identityFactory.nextSessionGeneration();
    dispatch({ type: VOICE_ACTIONS.START_REQUESTED, sessionGeneration });
    provider.updateContext?.({ sessionGeneration });
    provider.connect({
      url,
      setup,
      identity: { ...identity, sessionGeneration },
    });
    capture.start();
    persistence?.start({ sessionId: identity.sessionId, incognito: identity.incognito });
    started = true;
    return true;
  }

  function stop() {
    if (!started && state.phase === "idle") return false;
    dispatch({ type: VOICE_ACTIONS.STOP_REQUESTED, sessionGeneration: state.sessionGeneration });
    capture.stop();
    provider.close();
    playback.flush({ reason: "session-stop" });
    started = false;
    const closePromise = persistence?.close({
      reason: "user-stop",
      reconnectCount: state.reconnectCount,
      incompleteTurn: Boolean(state.activeTurnId),
    });
    dispatch({ type: VOICE_ACTIONS.STOPPED });
    if (closePromise?.catch) void closePromise.catch(() => {});
    return true;
  }

  function sendText(text) {
    if (!started || !text) return false;
    return provider.sendText(text);
  }

  function ingestCaptureFrame(frame, metadata = {}) {
    return capture.processFrame(frame, metadata);
  }

  function requestResponseStage(request = {}) {
    if (!responseStagingManager) return { stage: "skip", reason: "staging-not-configured" };
    return responseStagingManager.start({
      ...request,
      sessionGeneration: state.sessionGeneration,
      turnId: request.turnId || state.activeTurnId,
    });
  }

  function considerBackchannel(context = {}) {
    if (!backchannelManager) return { offer: false, reason: "backchannel-not-configured" };
    return backchannelManager.consider({
      ...context,
      sessionGeneration: state.sessionGeneration,
      turnId: context.turnId || state.activeTurnId,
      isModelSpeaking: state.isModelSpeaking,
    });
  }

  function subscribe(listener) {
    if (typeof listener !== "function") return () => {};
    listeners.add(listener);
    return () => listeners.delete(listener);
  }

  return Object.freeze({
    start,
    stop,
    sendText,
    ingestCaptureFrame,
    handleProviderEvent,
    requestResponseStage,
    considerBackchannel,
    subscribe,
    getState: () => state,
    getIdentity: currentIdentity,
    isStarted: () => started,
  });
}
