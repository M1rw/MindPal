function decodeBase64Pcm16(base64Data) {
  if (!base64Data) return new Int16Array();
  let bytes;
  if (typeof atob === "function") {
    const binary = atob(base64Data);
    bytes = new Uint8Array(binary.length);
    for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
  } else if (typeof Buffer !== "undefined") {
    bytes = new Uint8Array(Buffer.from(base64Data, "base64"));
  } else {
    throw new Error("No base64 decoder available");
  }
  return new Int16Array(bytes.buffer, bytes.byteOffset, Math.floor(bytes.byteLength / 2));
}

function pcm16ToFloat32(pcm) {
  const result = new Float32Array(pcm.length);
  for (let index = 0; index < pcm.length; index += 1) result[index] = pcm[index] / 0x8000;
  return result;
}

export function createPlaybackManager({
  audioContext = null,
  onEvent = () => {},
  now = () => Date.now(),
  outputSampleRate = 24000,
} = {}) {
  let activeGeneration = 0;
  let nextStartTime = 0;
  let playing = false;
  let sources = new Set();
  let muted = false;

  function emit(type, payload = {}) {
    onEvent(Object.freeze({ type, at: now(), ...payload }));
  }

  function setMuted(nextMuted) {
    muted = Boolean(nextMuted);
  }

  function flush({ generation = null, reason = "flush" } = {}) {
    const targetGeneration = generation == null ? activeGeneration : generation;
    for (const source of sources) {
      if (source.generation !== targetGeneration) continue;
      try { source.node.stop(); } catch { /* already ended */ }
      sources.delete(source);
    }
    if (targetGeneration === activeGeneration) {
      activeGeneration += 1;
      nextStartTime = 0;
      playing = false;
    }
    emit("playback.flushed", { generation: targetGeneration, activeGeneration, reason });
    return activeGeneration;
  }

  function beginGeneration(generation = activeGeneration + 1) {
    if (!Number.isInteger(generation) || generation <= activeGeneration) generation = activeGeneration + 1;
    flush({ reason: "new-generation" });
    activeGeneration = generation;
    nextStartTime = 0;
    return activeGeneration;
  }

  function schedule(base64Data, {
    generation = activeGeneration || 1,
    audioClass = "main",
    identity = {},
    gain = audioClass === "main" ? 1 : 0.55,
  } = {}) {
    if (!base64Data || muted) return false;
    if (generation < activeGeneration) return false;
    if (generation > activeGeneration) beginGeneration(generation);
    if (!audioContext || typeof audioContext.createBuffer !== "function") {
      emit("playback.scheduled", { generation, audioClass, identity, durationMs: 0, unavailable: true });
      return true;
    }

    const pcm = decodeBase64Pcm16(base64Data);
    if (pcm.length === 0) return false;
    const samples = pcm16ToFloat32(pcm);
    const buffer = audioContext.createBuffer(1, samples.length, outputSampleRate);
    buffer.copyToChannel(samples, 0, 0);
    const sourceNode = audioContext.createBufferSource();
    sourceNode.buffer = buffer;
    const gainNode = typeof audioContext.createGain === "function" ? audioContext.createGain() : null;
    if (gainNode) {
      gainNode.gain.value = gain;
      sourceNode.connect(gainNode);
      gainNode.connect(audioContext.destination);
    } else {
      sourceNode.connect(audioContext.destination);
    }

    const durationMs = (buffer.duration || 0) * 1000;
    const startAt = Math.max(audioContext.currentTime || 0, nextStartTime || 0);
    const entry = { generation, audioClass, identity, node: sourceNode };
    sources.add(entry);
    playing = true;
    sourceNode.onended = () => {
      sources.delete(entry);
      if (generation === activeGeneration && sources.size === 0) {
        playing = false;
        emit("playback.ended", { generation, audioClass });
      }
    };
    sourceNode.start(startAt);
    nextStartTime = startAt + (buffer.duration || 0);
    emit("playback.started", { generation, audioClass, identity, durationMs });
    return true;
  }

  function handleInterruption(identity = {}) {
    return flush({ generation: identity.playbackGeneration ?? activeGeneration, reason: "provider-interrupted" });
  }

  return Object.freeze({
    beginGeneration,
    schedule,
    flush,
    handleInterruption,
    setMuted,
    isPlaying: () => playing,
    getActiveGeneration: () => activeGeneration,
    getQueuedSourceCount: () => sources.size,
  });
}
